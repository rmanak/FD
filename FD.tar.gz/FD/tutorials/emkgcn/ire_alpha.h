void ire_alpha_(double *a,double *Trr,double *alpha,double *x,int *Nx,double *hx,double *res);
