void u_pi_(double *a,double *x,double *alpha,double *n_pi,double *n_pp,double *np1_pi,double *np1_pp,int *Nx,double *ht,double *hx,double *epsdis,int *phys_bdy,double *res);
