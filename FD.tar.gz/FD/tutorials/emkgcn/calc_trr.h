void calc_trr_(double *n_pi,double *n_pp,int *Nx,int *phys_bdy,double *res);
