void ire_pi_(double *a,double *n_pp,double *nm1_pi,double *np1_pi,double *alpha,double *x,int *Nx,double *ht,double *hx,double *res);
