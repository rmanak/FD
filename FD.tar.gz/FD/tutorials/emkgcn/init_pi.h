void init_pi_(double *x,double *n_phi,int *Nx,double *hx,double *myzero,double *idsignum,int *phys_bdy,double *res);
