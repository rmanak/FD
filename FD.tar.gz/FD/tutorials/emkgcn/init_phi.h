void init_phi_(double *x,int *Nx,double *A,double *x0,double *delx,double *res);
