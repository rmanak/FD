void ode_driver_(double *lna,double *lnalpha,double *a,double *alpha,double *Ttt,double *Trr,int *Nx,double *hx,double *x);
