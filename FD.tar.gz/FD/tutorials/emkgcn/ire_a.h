void ire_a_(double *Ttt,double *a,double *x,int *Nx,double *hx,double *res);
