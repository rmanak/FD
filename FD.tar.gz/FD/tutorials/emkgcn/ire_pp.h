void ire_pp_(double *n_pi,double *nm1_pp,double *a,double *alpha,double *np1_pp,int *Nx,double *ht,double *hx,double *res);
