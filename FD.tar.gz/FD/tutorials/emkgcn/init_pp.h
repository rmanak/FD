void init_pp_(double *x,double *n_phi,int *Nx,double *hx,double *myzero,int *phys_bdy,double *res);
