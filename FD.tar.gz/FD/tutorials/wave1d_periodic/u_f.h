void u_f_(double *n_f,double *n_f_t,double *np1_f,double *np1_f_t,int *Nx,double *ht,int *phys_bdy,double *res);
