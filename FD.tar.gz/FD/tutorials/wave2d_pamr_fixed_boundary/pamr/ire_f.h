void ire_f_(double *np1_f,double *n_f,double *nm1_f,int *Nx,int *Ny,double *ht,double *hx,double *hy,double *res);
