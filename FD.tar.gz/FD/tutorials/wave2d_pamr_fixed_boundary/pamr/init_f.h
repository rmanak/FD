void init_f_(double *y,double *x,int *Nx,int *Ny,double *A,double *xc,double *yc,double *delx,double *dely,double *res);
