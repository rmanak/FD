void res_f_t_(double *n_f,double *x,double *y,double *n_f_t,double *np1_f,double *np1_f_t,int *Nx,int *Ny,double *ht,double *hx,double *hy,double *myzero,int *phys_bdy,double *res);
