void init_f_t_(double *y,double *x,int *Nx,int *Ny,double *A,double *xc,double *yc,double *delx,double *dely,double *idsigx,double *idsigy,double *res);
