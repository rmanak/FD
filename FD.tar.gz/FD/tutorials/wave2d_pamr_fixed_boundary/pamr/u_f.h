void u_f_(double *n_f,double *x,double *y,double *n_f_t,double *np1_f,double *np1_f_t,int *Nx,int *Ny,double *ht,double *myzero,int *phys_bdy,double *res);
