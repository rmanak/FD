void update_f_(double *n_f,double *np1_f,double *x,int *Nx,double *T0,double *T1,double *ht,double *hx,double *myzero,int *phys_bdy,double *res);
