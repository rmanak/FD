void init_f_(double *x,int *Nx,double *T0,double *T1,double *xmax,double *xmin,double *res);
