void init_v_(double *x,int *Nx,double *d,double *p,double *vcons,double *res);
