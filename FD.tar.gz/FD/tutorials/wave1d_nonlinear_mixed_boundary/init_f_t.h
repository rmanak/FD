void init_f_t_(double *v,double *x,int *Nx,double *A,double *delx,double *idsignum,double *x0,double *res);
