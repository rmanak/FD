void u_f_t_(double *n_f,double *n_f_t,double *np1_f,double *np1_f_t,double *v,double *x,int *Nx,double *a,double *b,double *ht,double *hx,double *myzero,int *phys_bdy,double *res);
