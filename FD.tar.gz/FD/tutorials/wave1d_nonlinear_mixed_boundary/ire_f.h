void ire_f_(double *n_f,double *nm1_f,double *np1_f,double *v,int *Nx,double *a,double *b,double *ht,double *hx,double *res);
