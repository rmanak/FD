void init_f_(double *x,int *Nx,double *A,double *delx,double *x0,double *res);
