void ire_f_(double *n_f,double *nm2_f,double *np1_f,double *nm1_f,double *x,double *np2_f,int *Nx,int *Nz,double *ht,double *hx,double *hz,double *res);
