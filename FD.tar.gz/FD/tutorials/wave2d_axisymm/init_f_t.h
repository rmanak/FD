void init_f_t_(double *z,double *x,int *Nx,int *Nz,double *A,double *xc,double *zc,double *delx,double *delz,double *idsigx,double *idsigz,double *res);
