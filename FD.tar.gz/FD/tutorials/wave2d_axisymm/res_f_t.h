void res_f_t_(double *n_f,double *x,double *n_f_t,double *np1_f,double *np1_f_t,int *Nx,int *Nz,double *ht,double *hx,double *hz,int *phys_bdy,double *res);
