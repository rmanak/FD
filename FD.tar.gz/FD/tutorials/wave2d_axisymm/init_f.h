void init_f_(double *z,double *x,int *Nx,int *Nz,double *A,double *xc,double *zc,double *delx,double *delz,double *res);
