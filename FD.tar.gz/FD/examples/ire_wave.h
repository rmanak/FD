void ire_wave_(double *n_f,double *nm1_f,double *np1_f,int *Nx,double *ht,double *hx,double *res);
