void ire_a_(double *a,double *n_phi,double *nm1_phi,double *np1_phi,double *x,int *Nx,double *ht,double *hx,double *res);
