void init_to_gauss_(double *x,double *y,int *Nx,int *Ny,double *A,double *delx,double *dely,double *xc,double *yc,double *res);
