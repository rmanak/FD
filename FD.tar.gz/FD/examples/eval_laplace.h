void eval_laplace_(double *phi,double *x,double *z,int *Nx,int *Nz,double *hx,double *hz,double *myzero,int *phys_bdy,double *res);
